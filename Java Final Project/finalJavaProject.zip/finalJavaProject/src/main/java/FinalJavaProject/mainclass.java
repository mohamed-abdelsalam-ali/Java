/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalJavaProject;

/**
 *
 * @author atefi
 */
import smile.classification.RandomForest;
import smile.data.DataFrame;
import smile.data.formula.Formula;
import smile.data.measure.NominalScale;
import smile.data.vector.IntVector;
import smile.plot.swing.Histogram;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;


public class mainclass {
    String Wazafpath = "src/main/resources/rest/Wuzzuf_Jobs.csv";

    public mainclass() {
    }
    
       public static void main(String[] args) {
        mainclass mcls = new mainclass ();
        DAO getdf = new DAO ();
        DataFrame wazzafdf = getdf.readCSV (mcls.Wazafpath);
        

        //DataFrame trainData = sd.readCSV (sd.Wazafpath);
        
//        DataFrame testData = sd.readCSV (sd.testPath);
//        sd.getTrainDataSummery (trainData);
//        sd.processTrainData (trainData);
//        sd.plotData (trainData);
        
   }
//    public static void main(String[] args) throws IOException {
    
//            }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalJavaProject;
import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler;

import java.util.logging.Level;
import java.util.logging.Logger;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.stream.Collectors;
import smile.data.DataFrame;
import smile.data.Tuple;
import org.apache.commons.csv.CSVFormat;
import smile.io.Read;

//////////////////////////////////////////////////////////spark SQL
import java.util.Collections;
import java.util.HashMap;
import org.knowm.xchart.style.PieStyler;
// import sparkObject.spark.implicits._;
//import org.apache.spark.sql.functions.split;
//import spark.imlicits._;

/////////////////////////////////////
/**
 *
 * @author atefi
 */
public class DAO {

    //String xpath = "src\\main\\resources\\rest\\Wuzzuf_Jobs.csv";
    String Wazafpath = "src/main/resources/Wazaf/Wuzzuf_Jobs.csv";

    public static void main(String[] args) {
        DAO getdf = new DAO();
        DataFrame wazzafdf = getdf.readCSV(getdf.Wazafpath);
    }
    private DataFrame WazafDatafram;

    public DataFrame readCSV(String path) {
        CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        DataFrame df = null;
        DataFrame df1 = null;
        DataFrame df2 = null;
        DataFrame df4 = null;
        DAO DAoObj = new DAO();

        try {
            df = Read.csv(path, format);
            System.out.println("===============DATA summary ()==============");
            System.out.println(df.summary());
            System.out.println("===============DATA Structure ()==============");
            System.out.println(df.structure());

            System.out.println("===============ALL DATA==============");
            df = df.select("Title", "Company", "Location", "Type", "Level", "YearsExp", "Country", "Skills");
            System.out.println(df);

            System.out.println("===============Title And Company==============");
            df1 = df.select("Title", "Company");
            System.out.println(df1);

            System.out.println("===============Title ==============");
            df2 = df.select("Title");
            System.out.println(df2);
// Map<String, List<Job>> companiesJobsMap = allJobs.stream().collect(Collectors.groupingBy(c -> c.getCompany()));
            System.out.println("=======After Omitting null Rows==============");
            df = df.omitNullRows();
            System.out.println(df);

//            df3=df.select("Title").rdd.map(r => r(0)).collect();
            System.out.println("=======After Omitting Dubilcates Rows===???????????????===========");
//            System.out.println (df);
            Map<String, List<String>> myMaps = new HashMap<String, List<String>>();
//            for (Object item : df3) {
//                if (!myMaps.containsKey(item.getKey())) {
//                    myMaps.put(item.getKey(), new ArrayList<String>());
//                 }
//                    myMaps.get(item.getKey()).add(item.getValue());
//                System.err.println(item);
//             }
//            
// val listValues=df.select("state").map(f=>f.getString(0)) .collect.toList
//println(listValues)

        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
        WazafDatafram = df;
        System.out.println("****************/////////////////*******************");
        System.out.println(WazafDatafram);
        ////////////////////////////////////////Company + jobs sorded step 4////////////////////////////////////////////////

        List<POJO> df3 = DAoObj.getWazafList(WazafDatafram);
        Map<String, List<POJO>> collect = df3.stream().collect(Collectors.groupingBy(p -> p.getCompany()));
        HashMap<String, Integer> DataMap = new HashMap<String, Integer>();
        for (Map.Entry<String, List<POJO>> entry : collect.entrySet()) {
            String key = entry.getKey();
            List<POJO> val = entry.getValue();
            List<String> myList = new ArrayList<String>();
            for (POJO pojo : val) {

                myList.add(0, pojo.getTitle());
            }

            DataMap.put(key, myList.size());
            
        }
        DAoObj.drawPieChart(collect,"the jobs for each company ");
        int lenH = DataMap.size();
        System.out.println("number of companies sorted and distencit : " + lenH);
//////////////////////////////////////////Most popular jobs step 6////////////////////////////////////////////////
        System.out.println("===========================Counting All Jobs For Each Company in Order step 4 ===========================");
        DataMap.entrySet().stream().sorted(Map.Entry.comparingByValue()).distinct().forEach(System.out::println);

        System.out.println("===========================Most popular 10 jobs in Companies step 6 ===========================");
         DataMap.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).limit(10).distinct().forEach(System.out::println);

         Map<String, List<POJO>> collecttry = df3.stream().collect(Collectors.groupingBy(p -> p.getTitle()));
         System.out.println(collecttry);
        HashMap<String, Integer> DataMaptry = new HashMap<String, Integer>();
        for (Map.Entry<String, List<POJO>> entry : collecttry.entrySet()) {
            String key = entry.getKey();
            List<POJO> val = entry.getValue();
            List<String> myList = new ArrayList<String>();
            for (POJO pojo : val) {

                myList.add(0, pojo.getTitle());
            }

            DataMaptry.put(key, myList.size());
            
        }
        DAoObj.drawPieChart(collecttry,"most popular job titles");
         
         
           //DAoObj.drawPieChart((Map<String, List<POJO>>) DataMap.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).limit(10).distinct());
//Map<String, List<POJO>> collect = df3.stream().collect(Collectors.groupingBy(p -> p.getCompany()));




        System.out.println("===========================Most popular 10 Areas step 8 ===========================");

//         
//           for (int i = 0; i < 10; i++) {
//            int max = Collections.max(mapy.values());
//            
//            List MaxKy =mapy.entrySet().stream().filter(entry -> entry.getValue() == max).map(entry -> entry.getKey())
//                .collect(Collectors.toList());
//           System.out.println(MaxKy +" : "+max );
//           mapy.remove(max);
//        }
//           //////////////////////////////////////////////////////////////////////////////////////////////////////
        // getLocation
        System.out.println("===========================Most popular 10 Areas with Jobs step 8 ===========================");

//        Map<String, List<POJO>> collec1t= df3.stream ().collect (Collectors.groupingBy(p->p.getLocation()));
//        for (Map.Entry<String, List<POJO>> entry : collec1t.entrySet()) {
//            String key = entry.getKey();
//            List<POJO> val = entry.getValue();
//            for (POJO pojo : val) {
//                System.out.println(key+" : "+pojo.getTitle());
//            }
//            
//        }
        Map<String, List<POJO>> collectArea = df3.stream().collect(Collectors.groupingBy(p -> p.getLocation()));
        HashMap<String, Integer> DataMapArea = new HashMap<String, Integer>();
        for (Map.Entry<String, List<POJO>> entry : collectArea.entrySet()) {
            String key = entry.getKey();
            List<POJO> val = entry.getValue();
            List<String> myList = new ArrayList<String>();
            for (POJO pojo : val) {

                myList.add(0, pojo.getTitle());
            }

            DataMapArea.put(key, myList.size());
        }
        int lenArea = DataMapArea.size();
        DAoObj.drawPieChart(collectArea,"most popular areas with Jobs");

        DataMapArea.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).limit(10).distinct().forEach(System.out::println);
        System.out.println("============================ Skils ==============================");
       
System.out.println("============================ Skils ==============================");

//        System.out.println(df3.size());
            List<String> Allskils = new ArrayList<>();

        for (POJO p : df3) {
//                        System.out.println(p.getTitle());

            String[] skils = p.getSkils();
            for (int i = 0; i < skils.length; i++) {
                Allskils.add(skils[i]);
//                System.out.println(p.getTitle() + " : " + skils[i]);
            }
//             System.out.println(p.getTitle() + " : " + skils);

        }
             System.out.println(Allskils);
             
             Map<String, Integer> counts = new HashMap<String, Integer>(); 
 
        for (String str : Allskils) { 
            if (counts.containsKey(str)) { 
                counts.put(str, counts.get(str) + 1); 
            } else { 
                counts.put(str, 1); 
            } 
        } 
 
            for (Map.Entry<String, Integer> entry : counts.entrySet()) { 
//                System.out.println(entry.getKey() + " = " + entry.getValue()); 
            } 
          counts.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).limit(10).distinct().forEach(System.out::println);

        return df;
    }

    public DataFrame getWazafDatafram() {
        return WazafDatafram;
    }

    public List<POJO> getWazafList(DataFrame WazafDatafram) {
        // assert WazafDatafram != null;
        List<POJO> Wzaflist = new ArrayList<>();
        ListIterator<Tuple> iterator = WazafDatafram.stream().collect(Collectors.toList()).listIterator();

        while (iterator.hasNext()) {
            Tuple t = iterator.next();
            POJO p = new POJO();
            POJO.id += 1;
            p.pojoId = POJO.id;
            p.setTitle((String) t.get("Title"));
            p.setCompany((String) t.get("Company"));
            p.setLocation((String) t.get("Location"));
            p.setType((String) t.get("Type"));
            p.setLevel((String) t.get("Level"));
            p.setYearExp((String) t.get("YearsExp"));
            p.setCountry((String) t.get("Country"));
            p.setSkils(t.get("Skills").toString().split(","));

            Wzaflist.add(p);
        }
        return Wzaflist;
    }
  public void drawPieChart(final Map<String, List<POJO>> companiesJobsMap ,String chartname) {
        try {
            /*JFrame frame = new JFrame();
            frame.getContentPane().add(new MyComponent(JobTitlesMap));
            frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
            frame.setVisible(true);*/
            // Create Chart
            PieChart chart = new PieChartBuilder().width(1200).height(700).title(chartname)
                    .theme(Styler.ChartTheme.GGPlot2).build();

            // Customize Chart
            chart.getStyler().setLegendVisible(false);
            chart.getStyler().setAnnotationType(PieStyler.AnnotationType.LabelAndValue);
            chart.getStyler().setAnnotationDistance(1.3);
            chart.getStyler().setPlotContentSize(.8);
            chart.getStyler().setStartAngleInDegrees(90);

            for (Map.Entry<String, List<POJO>> entry : companiesJobsMap.entrySet()) {
                String key = entry.getKey();
                Integer value = entry.getValue().size();
                chart.addSeries(key, value);
            }

            // Show it
            new SwingWrapper(chart).displayChart();

            // Save it
            BitmapEncoder.saveBitmap(chart, "./Sample_Chart", BitmapEncoder.BitmapFormat.PNG);

            // or save it in high-res
            BitmapEncoder.saveBitmapWithDPI(chart, "./Sample_Chart_300_DPI", BitmapEncoder.BitmapFormat.PNG, 300);
        } catch (IOException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }  
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FinalJavaProject;

/**
 *
 * @author atefi
 */
public class POJO {
    
    static int id = 0;
    Integer pojoId;

    String Title;
    String Company;
    String Location;
    String Type;
    String Level;
    String YearExp;
    String Country;
    String[] Skils;

    public POJO() {
    }

    public POJO(String Title, String Company, String Location, String Type, String Level, String YearExp, String Country, String[] Skils) {
        this.Title = Title;
        this.Company = Company;
        this.Location = Location;
        this.Type = Type;
        this.Level = Level;
        this.YearExp = YearExp;
        this.Country = Country;
        this.Skils = Skils;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getCompany() {
        return Company;
    }

    public void setCompany(String Company) {
        this.Company = Company;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String Level) {
        this.Level = Level;
    }

    public String getYearExp() {
        return YearExp;
    }

    public void setYearExp(String YearExp) {
        this.YearExp = YearExp;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String[] getSkils() {
        return Skils;
    }

    public void setSkils(String[] Skils) {
        this.Skils = Skils;
    }
    
    
    
}
